<?
	if(isset($_POST['htmldata'])) {
		$htmldata = $_POST['htmldata'];
		$file = 'data.html';
		$filedata = fopen($file,'w') or die("can't open file");
		$htmldata = stripslashes($htmldata);
		fwrite($filedata, $htmldata);
		fclose($filedata);
	}
	header( 'Location: saved.php' ) ;
?>

