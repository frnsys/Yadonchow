<!doctype html>
<!--[if lt IE 7 ]> <html class="no-js ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]>    <html class="no-js ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]>    <html class="no-js ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<head> 
 <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

  <title>TO DO</title>
  <meta name="description" content="A simple yet feature-rich to do list written in jQuery, HTML, & CSS (with a dash of PHP).">
	<meta name="author" content="Francis Tseng">

  <link rel="stylesheet" href="style.css">

  <script src="jquery-1.5.1.min.js"></script>
	<script src="jquery-ui-1.7.2.custom.min.js"></script>
	<script src="todo.js"></script>



</head> 

<body>


<?php
$users = array("francis"=>"123456","kira"=>"123456","lydia"=>"123456","michael"=>"123456");
$colors = array("francis"=>"af73ca","kira"=>"8ca8bd","lydia"=>"a7c911","michael"=>"dd002c");
?>

<!-- user login -->
<!-- delete the following section if you want to disable user login -->
<?php 
if (isset($_POST["pass"]) && isset($_POST["user"]) && array_key_exists($_POST["user"], $users) && $users[$_POST["user"]]==$_POST["pass"] ) {
?>

<? $loggeduser = $_POST["user"];?>
<!-- end user login -->


	<div id="lang"><form action="save.php" method="POST" id="save"><input type="hidden" name="htmldata" id="htmldata" value="" /></form>
	<a href="#" class='button' id="savebutton">SAVE</a>
	</div>
		<div id="users">
			<h4>Users: </h4>
				<span id="user">
					<?	foreach ($colors as $k => $v) { ?>
					<span class="usersym" style="color:#<? echo $v; ?>;">&#x25C6;</span> <? echo $k; ?> &nbsp; &nbsp;
					<? } ?>
				</span>
		</div>

	
	
	
<!-- set c="y" for completed items & add completed date -->
<div id="container">
	<div id="main">
	</div><!-- main -->
	<div id="count">
		<span></span>
	</div>
</div><!-- container -->

<!-- usage instructions -->

<script type="text/javascript">
	$(document).ready(function() {
		//set usage div positioning
		var usage_left = (($(window).width() - $('#usage').width())/2)-30;
		$('#usage').css('left',usage_left);

		//close usage div by clicking outside of it
		$('#overlay').live('click',function() {
			$("#usage").fadeOut();
			$(this).fadeOut();
		});

		//open usage when "?" is clicked on
		$('#help').live('click',function() {
			$('#overlay').fadeIn();
			$('#usage').fadeIn();
		});
	});
</script>

<div id="help">
	<img src="img/help.png" />
</div>
<div id="overlay">
</div>
<div id="usage">
	<h2>Usage Instructions</h2>
	<h3>List Structure</h3>
	<p>The list is divided into sections, which are subdivided into subsections, which are divided into individual items:</p><br />
			<br /><div style="width:100%;text-align:center;"><strong>Sections => Subsections => Items</strong></div><br />
	<p><strong>Sections</strong> are added from the right-hand menu ("Add Section"). Sections can be sorted according to priority on the right-hand menu by clicking on the handles icon. Clicking on a section name in the priority list will jump you to that section. Sections can be hidden by clicking on that section name in the left-hand window.<br /><br />
	<strong>Subsections</strong> are added by clicking on the plus (+) sign that appears when you hover over a section name.<br /><br />
	<strong>Items</strong> are added by clicking on the plus (+) sign that appears when you hover over a subsection name. A due date can be assigned to each item. Leaving the due date set to DD/MM/YYYY will set a blank due date. Users can be assigned to items by click their corresponding colored diamond to the left of the item name.<br /><br />
		<strong>Sections, subsections, and items</strong> can be edited by clicking on their corresponding pencil icon. They can each be removed by clicking on their corresponding minus (-) sign.
	</p><br /><br />
	<h3>Managing Users</h3>
	<p>
		The users feature is <em>very</em> simple and can only be changed by directly editing index.php. Within that file are two PHP arrays with usernames and their corresponding passwords and colors. The user login feature can be disabled by editing index.php and deleting the two sections commented as "user login".
	</p>
</div>

<!-- user login -->
<!-- delete the following section if you want to disable user login -->
<?php 
}
else
{
if (isset($_POST['pass']) || isset($_POST['user']) ) {
	print "<p align=\"center\"><font color=\"red\"><b>Incorrect Username or Password</b><br>Please try again.</font></p>";
} ?>
	<form method="post">
		Please enter your username and password:<br/>
		<input name="user" type="text" size="30" maxlength="15"><br />
		<input name="pass" type="password" size="30" maxlength="15"><input value="Login" type="submit">
	</form>
<? } ?>
<!-- end user login -->


</body>

</html>
