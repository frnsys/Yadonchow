$(function(){
	$(document).ready(function() {
		$.ajax({ //loads html data from data.html
			type: 'GET',
			url: 'data.html?'+(new Date().getTime()),
			dataType: 'html',
			success: function(html, textStatus) {
				$('#main').append(html); //adds html from data.html to page
				$('#count span').replaceWith('<span>' + Math.floor(($("ul li[c=y]").length / $("ul li").length)*100) + "%" + '</span>'); //calculates initial percentage completed

				//generate array of user colors
				var userColors = new Array();
				var userCount = 0;
				$('.usersym').each(function() {
					var symcolor = $(this).attr('style');
					userColors[userCount]=symcolor;
					userCount++;
				});

				//set item as completed or uncompleted
				$("ul li .item").live('click',function() {
					if ($(this).parent().children().attr('class')=='ennewitem') { //checks if input is there, disables crossing out if true
					}
					else {
						if ($(this).parent().attr('c')=='y') {
							$(this).parent().attr('c','');
						}
						else {
							$(this).parent().attr('c','y');
						}
						//calculates percentage complete
						$('#count span').replaceWith('<span>' + Math.floor(($("ul li[c=y]").length / $("ul li").length)*100) + "%" + '</span>');
						//---------------
					}
				});
				//fixes selecting of users:
				$("ul li .item .userlist").live('click',function() {
					$(this).parent().click();
					$(this).parent().click();
				});
				//fixes pressing item buttons:
				$(".listgroup .add").live('click',function() {
					$(this).parent().click();
				});
				//---------------
				//
				$('.userlist').live('click',function() {
					$(this).parent().click();
				});

				//set listgroup as completed or uncompleted
				$('.listgroup').live('click',function() {
					if ($(this).attr('c')=='') {
						$(this).attr('c','y');
						$(this).find('h3').addClass("listgroupchecked");
						$(this).next('ul').find('li .item').each(function() {
							if ($(this).parent().attr('c')=='') {
								$(this).click();
							}
						});
					}
					else {
						$(this).attr('c','');
						$(this).find('h3').removeClass("listgroupchecked");
						$(this).next('ul').find('li .item').each(function() {
							if ($(this).parent().attr('c')=='y') {
								$(this).click();
							}
						});
						
					}
				});

				//sortable priority list
				$('.right ol').sortable({handle:".handle"}).disableSelection();
				//---------------

				//show/hide sections
				$("h2 a").click(function() {
					if ($(this).parent().parent().siblings('ul').css('display')=='none') {
						$(this).parent().parent().siblings('ul').css('display','block');
					}
					else {
					$(this).parent().parent().siblings('ul').css('display','none');
					}
				});
				//---------------

				//add new items
				$(".header .addsm").live('click',function() {
					$(this).parent().parent().parent().children("ul").append("<li><input type='text' name='ennewitem' class='ennewitem' value='' /><div class='ok'></div></li>");
					$('.ennewitem').focus();
				});
				$(".listgroup .add").live('click',function() {
					$(this).parent().next('ul').append("<li><input type='text' name='ennewitem' class='ennewitem' value='' /><input type='text' name='day' class='day' maxlength='2' value='DD' size='2' /><input type='text' name='month' class='month' maxlength='2' value='MM' size='2' /><input type='text' name='year' class='year' maxlength='4' value='YYYY' size='4' /><div class='ok'></div></li>");
					$('.ennewitem').focus();
				});
				//---------------
				
				//add new listgroups
				$(".header .add").live('click',function() {
					$(this).parent().parent().parent().children("ul").append("<div class='listgroup'><input type='text' name='ennewitem' class='ennewitem' value='' /><div class='ok'></div></div><ul></ul>");
					$('.ennewitem').focus();
				});
				//---------------

				//save the new item
				$('li .ok').live('mouseup',function() {
						var ennewitemval = $(this).siblings('.ennewitem').val();
						if ($(this).siblings('.day').val()) { //checks if there's a due date input
							var daynewitemval = $(this).siblings('.day').val();
							var monthnewitemval = $(this).siblings('.month').val();
							var yearnewitemval = $(this).siblings('.year').val();
							if (daynewitemval.length == 1) {
								daynewitemval = "0" + daynewitemval;
							}
							if (monthnewitemval.length == 1) {
								monthnewitemval = "0" + monthnewitemval;
							}
							if (yearnewitemval.length < 4) {
								while (yearnewitemval.length < 4) {
									yearnewitemval = "0" + yearnewitemval;
								}
							}
							if (daynewitemval == "DD") {
								daynewitemval = "";
							}
							if (monthnewitemval == "MM") {
								monthnewitemval = "";
							}
							if (yearnewitemval == "YY") {
								yearnewitemval = "";
							}
							if (daynewitemval == "" || monthnewitemval == "" || yearnewitemval == "") {
								$(this).parent().append('<div class="item"><span class="userlist"></span><p >' + ennewitemval + '</p><div class="duedate"></div></div><div class="liright"><div class="edit"></div><div class="remove"></div></div>');
							}
							else {
								$(this).parent().append('<div class="item"><span class="userlist"></span><p >' + ennewitemval + '</p><div class="duedate">' + daynewitemval + '.' + monthnewitemval + '.' + yearnewitemval +'</div></div><div class="liright"><div class="edit"></div><div class="remove"></div></div>');
							}
							$(this).siblings('.day').remove();												
							$(this).siblings('.month').remove();												
							$(this).siblings('.year').remove();
							$(this).siblings('.ennewitem').remove();												
							$(this).parent().attr('c','');
							for (i=0;i<userColors.length;i++) {
								$(this).parent().find('.userlist').append('&nbsp;<span class="userselect unselecteduser" style="'+userColors[i]+'">&#x25C6;</span>&nbsp;');
							}	
							$(this).remove();
						}
						else {
							$(this).parent().append('<div class="item"><span class="userlist"></span><p >' + ennewitemval + '</p></div><div class="liright"><div class="edit"></div><div class="remove"></div></div>');
							$(this).siblings('.ennewitem').remove();												
							$(this).parent().attr('c','');
							for (i=0;i<userColors.length;i++) {
								$(this).parent().find('.userlist').append('&nbsp;<span class="userselect unselecteduser" style="'+userColors[i]+'">&#x25C6;</span>&nbsp;');
							}	
							$(this).remove();
						}
														

				});
				//---------------
				
				//delete item
				$('li .remove').live('click',function() {
					$(this).parent().parent().remove();
				});
				//---------------
				
				//delete listgroup
				$('.listgroup .remove').live('click',function() {
					var confirmremove = confirm('Are you sure you want to delete this list group? This will delete all of its items.');
					if (confirmremove == true) {
						$(this).parent().next('ul').remove();
						$(this).parent().remove();
					}
					else {
						return false;
					}
				});
				//---------------
				
				//delete section
				$('.header .remove').live('click',function() {
					var confirmremove = confirm('Are you sure you want to delete this section? This will delete all of its items.');
					if (confirmremove == true) {
						var headerid = $(this).parent().parent().parent().attr('id');
						$(this).parent().parent().parent().remove();
						$('a[href="#'+headerid+'"]').parent().remove();
					}
					else {
						return false;
					}
				});
				//---------------


				//edit item
				$('li .edit').live('click',function() {
					var encontent = $(this).parent().siblings('.item').children('p').text();
					var fulldate = $(this).parent().siblings('.item').children('.duedate').text();
					var day = fulldate.slice(0,2);
					var month = fulldate.slice(3,5);
					var year = fulldate.slice(6,10);
					if (fulldate) { //checks if there's a date to edit
						$(this).parent().siblings().remove();
						$(this).parent().parent().append("<input type='text' name='ennewitem' class='ennewitem' value='" + encontent + "' /><input type='text' name='day' class='day' maxlength='2' value='" + day + "' size='2' /><input type='text' name='month' class='month' maxlength='2' value='" + month + "' size='2' /><input type='text' name='year' class='year' maxlength='4' value='" + year + "' size='4' /><div class='ok'></div>");
						$(this).parent().remove();
					}
					else {
						$(this).parent().siblings().remove();							
						$(this).parent().parent().append("<input type='text' name='ennewitem' class='ennewitem' value='" + encontent + "' /><input type='text' name='day' class='day' maxlength='2' value='DD' size='2' /><input type='text' name='month' class='month' maxlength='2' value='MM' size='2' /><input type='text' name='year' class='year' maxlength='4' value='YYYY' size='4' /><div class='ok'></div>");
						$(this).parent().remove();
					}
					$('input').focus();
				});
				//---------------
				
				//edit listgroup title
				$('.listgroup .edit').live('click',function() {
					var encontent = $(this).parent().children('h3').text();
					$(this).siblings().remove();
					$(this).parent().append("<input type='text' name='ennewitem' class='ennewitem' value='" + encontent + "' /><div class='ok'></div>");
					$(this).remove();
					$('input').focus();						
				});

				$('.listgroup .ok').live('mouseup',function() {
					var ennewitemval = $(this).siblings('.ennewitem').val();
					$(this).parent().append('<h3 >' + ennewitemval + '</h3><div class="add"></div><div class="edit"></div><div class="remove"></div></div>');
					$(this).siblings('.ennewitem').remove();												
					$(this).parent().attr('c','');
					$(this).remove();
				});
				//---------------
			
				//edit header
				$('.header .edit').live('click',function() {
					var encontent = $(this).parent().children('a').text();
					$(this).siblings().remove();
					$(this).parent().append("<input type='text' name='ennewitem' class='ennewitem' value='" + encontent + "' /><div class='ok'></div>");
					$(this).remove();
					$('input').focus();						
				});

				$('.header .ok').live('mouseup',function() {
					var ennewitemval = $(this).siblings('.ennewitem').val();
					$(this).parent().append('<a >' + ennewitemval + '</a><div class="add"></div><div class="edit"></div><div class="remove"></div></div>');
					var anchor = $(this).parent().parent().parent().find('.anchor').attr('name');
					if (anchor == 'tempid') {
						chararray = ennewitemval.split('');
						var idnum = "";
						for (i=0;i<chararray.length;i++) {
							idnum = idnum + chararray[i].charCodeAt();
						}
						$(this).parent().parent().parent().find('.anchor').attr('name',idnum);
						$(this).parent().parent().parent().attr('id',idnum);
						$('ol#priority-items').append("<li style='' class=''><a  href='#"+idnum+"'>"+ennewitemval+"</a><div class='handle'></div></li>")
					}
					$('a[href="#'+anchor+'"]').text(ennewitemval);
					$(this).siblings('.ennewitem').remove();												
					$(this).parent().attr('c','');
					$(this).remove();
				});
				//---------------
				
				//add new section
				$('.addsection').live('click',function() {
					$(this).parent().parent().parent().children(".sections").append("<div id='tempid'><a name='tempid' class='anchor'></a><hr><div class='header'><h2><input type='text' name='ennewitem' class='ennewitem' value='' /><div class='ok'></div></h2></div><ul></ul></div>");
					$('.ennewitem').focus();
				});
				//---------------
				
				
				$('.unselecteduser').live('click',function() {
					$(this).removeClass('unselecteduser');
					$(this).addClass('selecteduser');
					var thiscolor = $(this).attr('style');
				});
				$('.selecteduser').live('click',function() {
					$(this).removeClass('selecteduser');
					$(this).addClass('unselecteduser');
				});


			},
			error: function(xhr, textStatus, errorThrown) {
				alert('An error occurred!');
			}
		});

		
		//hitting enter saves an item
		$('input').live('keypress', function (e) {
			if ( e.keyCode == 13 ){
				 $(this).parent().find('.ok').mouseup();
			}
		});		
		//---------------
	
	});
});
